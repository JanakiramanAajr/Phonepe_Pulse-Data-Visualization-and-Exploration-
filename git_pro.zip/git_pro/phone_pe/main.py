import streamlit as st
import mysql.connector as sql
st.markdown("# Main page 🎈")
st.sidebar.markdown("# Main page 🎈")
st.markdown("# Page 2 ❄️")
st.sidebar.markdown("# Page 2 ❄️")
