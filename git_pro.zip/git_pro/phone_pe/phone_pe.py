import streamlit as st
import mysql.connector as sql
import pandas as pd
import streamlit as st
import plotly.graph_objects as go
tab1, tab2, tab3 = st.tabs(["HOME", "EXPLORE DATA", "DATA2"])

with tab1:

with tab2:


    # Data preparation (replace with your data)
    Data_Aggregated_Transaction_df = pd.read_csv("D:\git_pro\poptable.csv")
    data = [...]  # Your data with latitude, longitude, and values

    # Streamlit app
    st.title("Interactive Map Visualization")

    # Create dropdown for selecting data
    selected_data = st.selectbox("Select data to display:", ["Data 1", "Data 2", "Data 3"])

    # Create Plotly map based on selected data
    fig = go.Figure(go.Scattergeo(
        lon=data[selected_data]['longitude'],
        lat=data[selected_data]['latitude'],
        text=data[selected_data]['values'],
        mode='markers',
    ))

    # Customize map appearance if needed
    fig.update_geos(projection_type="orthographic")

    # Display Plotly map using Streamlit
    st.plotly_chart(fig)
with tab3:
   st.header("An owl")
   st.image("https://static.streamlit.io/examples/owl.jpg", width=200)